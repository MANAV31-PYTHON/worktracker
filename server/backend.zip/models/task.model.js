import mongoose from "mongoose";

const assigneeSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    status: {
      type: String,
      enum: ["PENDING", "IN_PROGRESS", "COMPLETED", "BLOCKED"],
      default: "PENDING",
    },

    progress: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },
  },
  { _id: false }
);

const taskSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },

    description: String,

    // ✅ NEW: multiple assignees with individual tracking
    assignees: {
      type: [assigneeSchema],
      required: true,
      validate: {
        validator: function (value) {
          return Array.isArray(value) && value.length > 0;
        },
        message: "At least one assignee is required",
      },
    },

    assignedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // 🔁 Task-level status (overall summary)
    status: {
      type: String,
      enum: ["PENDING", "IN_PROGRESS", "COMPLETED", "BLOCKED"],
      default: "PENDING",
    },

    priority: {
      type: String,
      enum: ["LOW", "MEDIUM", "HIGH"],
      default: "MEDIUM",
    },

    deadline: Date,

    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);
taskSchema.pre("save", function (next) {
  this.updateOverallStatus();
  next();
});

taskSchema.methods.updateOverallStatus = function () {
  const statuses = this.assignees.map(a => a.status);

  if (statuses.every(s => s === "COMPLETED")) {
    this.status = "COMPLETED";
  } else if (statuses.some(s => s === "IN_PROGRESS")) {
    this.status = "IN_PROGRESS";
  } else if (statuses.some(s => s === "BLOCKED")) {
    this.status = "BLOCKED";
  } else {
    this.status = "PENDING";
  }
};

taskSchema.pre("findOneAndUpdate", function (next) {
  const update = this.getUpdate();

  if (update.assignees) {
    const statuses = update.assignees.map(a => a.status);

    if (statuses.every(s => s === "COMPLETED")) {
      update.status = "COMPLETED";
    } else if (statuses.some(s => s === "IN_PROGRESS")) {
      update.status = "IN_PROGRESS";
    } else if (statuses.some(s => s === "BLOCKED")) {
      update.status = "BLOCKED";
    } else {
      update.status = "PENDING";
    }
  }

  next();
});

taskSchema.path("assignees").validate(function (value) {
  const userIds = value.map(v => v.user.toString());
  return new Set(userIds).size === userIds.length;
}, "Duplicate assignees are not allowed");

export default mongoose.model("Task", taskSchema);
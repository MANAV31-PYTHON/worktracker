import express from "express";
import { create, getAll, remove } from "../controllers/user.controller.js";
import { protect, authorizeRoles } from "../middlewares/auth.middleware.js";

const router = express.Router();

// 👑 Super Admin & Admin can create users
router.post("/", protect, authorizeRoles("SUPER_ADMIN", "ADMIN"), create);

// 👑 View users
router.get("/", protect, authorizeRoles("SUPER_ADMIN", "ADMIN"), getAll);

// 👑 Delete user
router.delete("/:id", protect, authorizeRoles("SUPER_ADMIN", "ADMIN"), remove);

export default router;
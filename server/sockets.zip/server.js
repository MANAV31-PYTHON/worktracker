import app from "./app.js";
import connectDB from "./config/db.js";
import dotenv from "dotenv";
import { initSocket } from "./sockets/socket.js";

dotenv.config();

const PORT = process.env.PORT || 5000;
initSocket(server);
connectDB();

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
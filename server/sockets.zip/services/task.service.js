import Task from "../models/task.model.js";
import User from "../models/user.model.js";
import { createLog } from "./taskLog.service.js";
import { sendNotification } from "../sockets/socket.js";

/**
 * 📌 CREATE TASK
 */
export const createTask = async (data, currentUser) => {
  const { title, description, assignedTo, priority, deadline } = data;

  if (!title || !assignedTo) {
    throw new Error("Title and assignedTo are required");
  }

  // 🔒 Only Admin/SuperAdmin can assign
  if (!["ADMIN", "SUPER_ADMIN"].includes(currentUser.role)) {
    throw new Error("Not authorized to assign tasks");
  }

  const employee = await User.findById(assignedTo);
  if (!employee || employee.role !== "EMPLOYEE") {
    throw new Error("Invalid employee");
  }

  const task = await Task.create({
    title,
    description,
    assignedTo,
    assignedBy: currentUser.id,
    priority,
    deadline,
  });

  // 🔔 Send Notification (safe)
  try {
    sendNotification(assignedTo.toString(), "task_assigned", {
      message: "New task assigned",
      task,
    });
  } catch (err) {
    console.error("Notification error:", err.message);
  }

  return task;
};

/**
 * 📌 GET TASKS (Role-based)
 */
export const getTasks = async (currentUser) => {
  if (currentUser.role === "SUPER_ADMIN") {
    return await Task.find({ isDeleted: false })
      .populate("assignedTo", "name email")
      .populate("assignedBy", "name email");
  }

  if (currentUser.role === "ADMIN") {
    return await Task.find({
      assignedBy: currentUser.id,
      isDeleted: false,
    }).populate("assignedTo", "name email");
  }

  if (currentUser.role === "EMPLOYEE") {
    return await Task.find({
      assignedTo: currentUser.id,
      isDeleted: false,
    });
  }

  throw new Error("Invalid role");
};

/**
 * 📌 UPDATE TASK
 */
export const updateTask = async (taskId, data, currentUser) => {
  const task = await Task.findById(taskId);
  if (!task) throw new Error("Task not found");

  const oldStatus = task.status;
  const oldProgress = task.progress;

  // 🔒 Employee can update only their own task
  if (
    currentUser.role === "EMPLOYEE" &&
    task.assignedTo.toString() !== currentUser.id
  ) {
    throw new Error("Not allowed");
  }

  // 🧑‍💻 Employee restrictions
  if (currentUser.role === "EMPLOYEE") {
    if (data.progress !== undefined) task.progress = data.progress;
    if (data.status) task.status = data.status;
  } else {
    Object.assign(task, data);
  }

  await task.save();

  // 📝 AUTO LOGGING
  if (oldStatus !== task.status || oldProgress !== task.progress) {
    try {
      await createLog({
        taskId: task._id,
        userId: currentUser.id,
        message: `Updated task: Status ${oldStatus} → ${task.status}, Progress ${oldProgress}% → ${task.progress}%`,
        progress: task.progress,
        status: task.status,
      });
    } catch (err) {
      console.error("Log error:", err.message);
    }
  }

  // 🔔 Notify assigned employee
  try {
    sendNotification(task.assignedTo.toString(), "task_updated", {
      message: "Task updated",
      task,
    });
  } catch (err) {
    console.error("Notification error:", err.message);
  }

  return task;
};

/**
 * 📌 DELETE TASK (Soft Delete)
 */
export const deleteTask = async (taskId, currentUser) => {
  const task = await Task.findById(taskId);
  if (!task) throw new Error("Task not found");

  // 🔒 Admin restriction
  if (
    currentUser.role === "ADMIN" &&
    task.assignedBy.toString() !== currentUser.id
  ) {
    throw new Error("Not allowed");
  }

  task.isDeleted = true;
  await task.save();

  // 🔔 Notify employee
  try {
    sendNotification(task.assignedTo.toString(), "task_deleted", {
      message: "Task has been deleted",
      taskId: task._id,
    });
  } catch (err) {
    console.error("Notification error:", err.message);
  }

  return { message: "Task deleted successfully" };
};
import TaskLog from "../models/taskLog.model.js";

export const createLog = async ({ taskId, userId, message, progress, status }) => {
  return await TaskLog.create({
    taskId,
    userId,
    message,
    progress,
    status,
  });
};

export const getTaskLogs = async (taskId) => {
  return await TaskLog.find({ taskId })
    .populate("userId", "name role")
    .sort({ createdAt: -1 });
};
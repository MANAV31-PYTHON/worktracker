import User from "../models/user.model.js";
import bcrypt from "bcryptjs";

export const createUser = async (data, currentUser) => {
  const { name, email, password, role } = data;

  // 🔒 Role restriction
  if (currentUser.role === "ADMIN" && role === "ADMIN") {
    throw new Error("Admin cannot create another admin");
  }

  const existing = await User.findOne({ email });
  if (existing) throw new Error("User already exists");

  const hashedPassword = await bcrypt.hash(password, 10);

  const user = await User.create({
    name,
    email,
    password: hashedPassword,
    role,
    createdBy: currentUser.id,
  });

  return user;
};

export const getUsers = async (currentUser) => {
  if (currentUser.role === "SUPER_ADMIN") {
    return await User.find();
  }

  if (currentUser.role === "ADMIN") {
    return await User.find({ role: "EMPLOYEE" });
  }

  throw new Error("Not allowed");
};

export const deleteUser = async (userId, currentUser) => {
  const user = await User.findById(userId);

  if (!user) throw new Error("User not found");

  // 🔒 Role restriction
  if (currentUser.role === "ADMIN" && user.role !== "EMPLOYEE") {
    throw new Error("Admin can delete only employees");
  }

  await user.deleteOne();
  return { message: "User deleted" };
};
import { Server } from "socket.io";

let io;
const users = new Map(); // userId → socketId

export const initSocket = (server) => {
  io = new Server(server, {
    cors: {
      origin: "*",
    },
  });

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    // 🔑 Register user
    socket.on("register", (userId) => {
      users.set(userId, socket.id);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);

      // remove user
      for (let [key, value] of users.entries()) {
        if (value === socket.id) {
          users.delete(key);
        }
      }
    });
  });
};

export const sendNotification = (userId, event, data) => {
  const socketId = users.get(userId);
  if (socketId && io) {
    io.to(socketId).emit(event, data);
  }
};